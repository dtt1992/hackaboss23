# Ejercicio 1

Escribe una función que encuentre todos los números primos comprendidos en un rango (a determinar por los parámetros que se le pasen).

Recuerda que dividir el problema en pasos más sencillos te ayudaá a encontrar la solución.

** Ejemplo input: ** 100, 200.
