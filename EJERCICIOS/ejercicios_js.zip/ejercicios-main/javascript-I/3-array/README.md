# Ejercicio 3

Escribe un código que, partiendo de un array inicial, elimine las strings repetidas del mismo.
Haz que sea una función que reciba el array como parámetro (y por tanto elimine los lementos repetidos de cualquier array).

Utiliza una función externa al bucle (que reciba nombre y edad) para generar y sacar la frase correspondiente.

** Ejemplo input: **

```javascript
const names = [
  "A-Jay",
  "Manuel",
  "Manuel",
  "Eddie",
  "A-Jay",
  "Su",
  "Reean",
  "Manuel",
  "A-Jay",
  "Zacharie",
  "Zacharie",
  "Tyra",
  "Rishi",
  "Arun",
  "Kenton",
];
```

** Ejemplo output: **

```javascript
const names = [
  "A-Jay",
  "Manuel",
  "Eddie",
  "Su",
  "Reean",
  "Zacharie",
  "Tyra",
  "Rishi",
  "Arun",
  "Kenton",
];
```
