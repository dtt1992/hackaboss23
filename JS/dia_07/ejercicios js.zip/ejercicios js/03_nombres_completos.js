// Tu pareja no recuerda bien los nombres y apellidos de cada integrante de tu familia.
// Ayúdale, puedes hacer un listado con el nombre y apellido?
// Algo así como: ['Juan Sánchez', 'Julia Pérez', 'Pedro Sánchez', 'Sofía Sánchez', 'Manuel Sánchez']

