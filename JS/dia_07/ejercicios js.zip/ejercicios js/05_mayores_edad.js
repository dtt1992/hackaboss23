// El Gobierno se ha quedado sin dinero y ya no puede seguir regalando pasajes en tren.
// A si que quieren saber cuántos integrantes de tu familia son menores de edad.
// De esa forma podrán contabilizar la cantidad de viajes posibles y finalmente aumentar los impuestos.
// Ayúdales!, entrégales la cantidad de menores de 18 en tu familia.
