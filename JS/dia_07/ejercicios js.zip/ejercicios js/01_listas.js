// Tu pareja irá al supermercado por primera vez y no sabe qué cosas comprar.
// Ayúdale! hazle una lista de los 10 productos que no pueden faltar en tu casa