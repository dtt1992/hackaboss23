// Escribe una función que reciba una palabra y retorne verdadero o falso según sea palíndromo o no.
// Un palíndromo es una palabra que escrita al revés retorna el mismo resultado.
// Por ejemplo los nombres Hannah, Ana, Bob ó la frase 'Dábale arroz a la zorra el abad'