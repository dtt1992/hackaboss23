// Lo creado en el ejercicio anterior esta ok, pero sería bueno crear una función que permita realizar este trabajo.
// Así podremos reutilizarla cuantas veces queramos!
// Lo que se necesita es: crear una función que reciba el listado de familiares.
// Esa función itera a cada integrante y llama a otra que creará el texto de cada uno de los integrantes, 
// devolviéndoselo a la función principal que será la que almacenará los datos antes de finalmente retornarlos todos juntos.