// Haremos un juego, el ordenador elegirá un número entre el 1 y el 10.
// Y te preguntará el número un máximo de 3 veces: si aciertas tu ganas, si después de 3 intentos no aciertas, pierdes.
